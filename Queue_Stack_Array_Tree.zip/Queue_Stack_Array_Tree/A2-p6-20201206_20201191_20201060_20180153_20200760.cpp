/**
*Nada Mohamed Ahmed Gad El-kaream   20201191    s2
*Hager Mohamed Abd Elhalim Ghareeb  20201206    s2
*Donia Ahmed Abozeid Mohamed        20201060    s12
*Abd El-Rahman Taha Abd El-Bar      20180153    s10
*Ziad adel sayyed mohammed          20200760    s13
**/
#include <iostream>
#include <cstring>
using namespace std;
class TreeNode
{
public:
    char value;
    TreeNode*right;
    TreeNode*left;


    TreeNode( char v)
    {
        value =v;
        right=nullptr;
        left=nullptr;

    }
};

class Stack
{
public:
    TreeNode*newnode;
    Stack*s;
    Stack(TreeNode*n)
    {
        newnode= n;
        s = nullptr;
    }
};

class   Convert_To_Expression_Tree
{
public:
    Stack*top;
    Convert_To_Expression_Tree ()
    {
        top = nullptr;
    }

    void push(TreeNode *newnode)
    {
        if (top == NULL)
            top = new Stack(newnode);
        else
        {
            Stack*curr = new Stack(newnode);
            curr->s=top;
            top = curr;
        }
    }
    TreeNode *pop()
    {
        if (top == NULL)
        {
            cout<<"Undefined"<<endl;
        }
        else
        {
            TreeNode *node = top->newnode;
            top = top->s;
            return node;
        }
    }

    char Insert(char v)
    {
        if(v >= '0' && v<= '9999')
        {
            TreeNode *curr = new TreeNode(v);
            push(curr);
            return v;
        }
        else if(v == '+' || v == '-' || v== '*' || v == '/')
        {
            TreeNode *curr = new TreeNode(v);
            curr->left = pop();
            curr->right= pop();
            push(curr);
            return v;
        }
        else
        {
            cout<<"Invalid Expression"<<endl;
            return 0;
        }
    }
    void buildTree(string eqn)
    {


        for (int i = eqn.length()- 1; i >= 0; i--)
            Insert(eqn[i]);
    }
    void preorder(TreeNode *node)
    {
        if (node != NULL)
        {
            cout<<node->value;
            preorder(node->left);
            preorder(node->right);
        }
    }
    TreeNode* Back()
    {
        return top->newnode;
    }

    void prefix()
    {
        preorder( Back());

    }
    double toDigit(  char value)
    {
        return value - 48;
    }
    double evaluate(  TreeNode* root )
    {

        if (root==nullptr)
            return 0;
        if (root->left==nullptr && root->right==nullptr)
            return toDigit(root->value);
        double leftvalue = evaluate(root->left);
        double rightvalue = evaluate(root->right);
        if (root->value=='*')
            return leftvalue*rightvalue;
        else if(root->value=='/')
            return leftvalue/rightvalue;
        else if (root->value=='+')
            return leftvalue+rightvalue;
        else
            return leftvalue-rightvalue;
    }

    double evaluate()
    {
        return evaluate(Back());
    }
};
int main()
{
    string s;
    Convert_To_Expression_Tree et;
    cout<<"Enter your Prefix Form"<<endl;
    s="+3*4/82";
    //cout<<"Enter your Prefix Expression"<<endl;
    //cin>>s;
    et.buildTree(s);
    cout<<"prefix Form is   ";
    et.prefix();
    cout<<"\n";
    cout<<"evaluation is   ";
    cout<<et.evaluate()<<endl;
    cout<<"\n********************************************************"<<endl;
    cout<<"Enter your Prefix Form"<<endl;
    s="*-23/42";
    //cout<<"Enter your Prefix Expression"<<endl;
    //cin>>s;
    et.buildTree(s);
    cout<<"prefix Form is   ";
    et.prefix();
    cout<<"\n";
    cout<<"evaluation is   ";
    cout<<et.evaluate()<<endl;
    cout<<"\n********************************************************"<<endl;
    cout<<"Enter your Prefix Form"<<endl;
    s="/*+325-31";
    //cout<<"Enter your Prefix Expression"<<endl;
    //cin>>s;
    et.buildTree(s);
    cout<<"prefix Form is   ";
    et.prefix();
    cout<<"\n";
    cout<<"evaluation is   ";
    cout<<et.evaluate()<<endl;
    cout<<"\n********************************************************"<<endl;
    cout<<"Enter your Prefix Expression"<<endl;
    s="+*2-314";
    //cout<<"Enter your Prefix Expression"<<endl;
    //cin>>s;
    et.buildTree(s);
    cout<<"prefix Form is   ";
    et.prefix();
    cout<<"\n";
    cout<<"evaluation is   ";
    cout<<et.evaluate()<<endl;
    cout<<"\n********************************************************"<<endl;
    cout<<"Enter your Prefix Form"<<endl;
    s="/2+5*33";
    //cout<<"Enter your Prefix Expression"<<endl;
    //cin>>s;
    et.buildTree(s);
    cout<<"prefix Form is   ";
    et.prefix();
    cout<<"\n";
    cout<<"evaluation is   ";
    cout<<et.evaluate()<<endl;
    cout<<"\n********************************************************"<<endl;
}
/*#include <iostream>
using namespace std;
#include<cstring>
class node
{
public:
    string value;
    node *left;
    node*right;
    node(string x)
    {
        value = x;
        left=nullptr;
        right=nullptr;

    }
};
int Convert_Into_Int(string s)
{
    int  number= 0;
    if(s[0]!='-'){
        for (int i=0; i<s.length(); i++)
            number = number*10 + (int(s[i])-48);
    }
    else
    {
      for (int i=1; i<s.length(); i++)
        number = number*10 + (int(s[i])-48);
        number = number*-1;
    }

    return number;
}
int evaluate(node*root)
{
    if (root==nullptr)
        return 0;
    if (root->left==nullptr && root->right==nullptr)
        return Convert_Into_Int(root->value);
     int leftvalue = evaluate(root->left);
     int rightvalue = evaluate(root->right);
       if (root->value=="*")
          return leftvalue*rightvalue;
       else if(root->value=="/")
          return leftvalue/rightvalue;
       else if (root->value=="+")
          return leftvalue+rightvalue;
      else
          return leftvalue-rightvalue;
}
int main()
{
    node *root = new node("+");
    root->left = new node("3");
    root->right=new node("*");
    root->right->left = new node("4");
    root->right->right = new node("/");
    root->right->right->left=new node("8");
    root->right->right->right=new node("2");
    cout << evaluate(root) << endl;

    delete(root);

    node *Root = new node("+");
    Root->left = new node("3");
    Root->right=new node("*");
    Root->right->left = new node("4");
    Root->right->right = new node("/");
    Root->right->right->left=new node("8");
    Root->right->right->right=new node("2");
    cout << evaluate(Root) << endl;
    delete(Root);
    node *r = new node("+");
    r->left = new node("3");
    r->right=new node("*");
    r->right->left = new node("4");
    r->right->right = new node("/");
    r->right->right->left=new node("8");
    r->right->right->right=new node("2");
    cout << evaluate(r) << endl;
    delete(r);
    node *root = new node("+");
    root->left = new node("3");
    root->right=new node("*");
    root->right->left = new node("4");
    root->right->right = new node("/");
    root->right->right->left=new node("8");
    root->right->right->right=new node("2");
    cout << evaluate(root) << endl;
    delete(root);
    node *root = new node("+");
    root->left = new node("3");
    root->right=new node("*");
    root->right->left = new node("4");
    root->right->right = new node("/");
    root->right->right->left=new node("8");
    root->right->right->right=new node("2");
    cout << evaluate(root) << endl;
    return0;
    }*/
