/**
*Nada Mohamed Ahmed Gad El-kaream   20201191    s2
*Hager Mohamed Abd Elhalim Ghareeb  20201206    s2
*Donia Ahmed Abozeid Mohamed        20201060    s12
*Abd El-Rahman Taha Abd El-Bar      20180153    s10
*Ziad adel sayyed mohammed          20200760    s13
**/
#include <iostream>
#include <queue>
using namespace std;
struct TreeNode
{
    int val;
    TreeNode *left;
    TreeNode *right;
    TreeNode():val(0),left(nullptr),right(nullptr) {}
    TreeNode(int x):val(x),left(nullptr),right(nullptr) {}
    TreeNode(int x,TreeNode *left,TreeNode *right):val(0),left(left),right(left) {}
};
class Solution
{
public:
    void String_Left_root(TreeNode*node,string &s)
    {
        if(node == NULL)
            return;
        String_Left_root(node->left,s);
        s =s + to_string(node->val);
        String_Left_root(node->right,s);
    }
    void String_right_root(TreeNode*node,string &s)
    {
        if(node == NULL)
            return;
        String_right_root(node->right,s);
        s =s + to_string(node->val);
        String_right_root(node->left,s);
    }
    bool isSymmetric(TreeNode* root)
    {
        if(root == NULL)
            return true;
        string string_left,string_right;
        String_Left_root(root->left,string_left);
        String_right_root(root->right,string_right);
        if(string_left == string_right)
            return true;
        return false;
    }
};
void printTree(TreeNode*root)
{
    if(root != NULL)
    {
        cout<<" = [ ";
        queue<TreeNode *>Queue;
        Queue.push(root);
        while(!Queue.empty())
        {
            TreeNode*currentNode=Queue.front();
            Queue.pop();
            if(currentNode == NULL )
                cout<<"null";
            else
            {
                cout<<currentNode->val;
                if(currentNode->left)
                    Queue.push(currentNode->left);
                else if(currentNode->left == NULL&&currentNode->right != NULL)
                    Queue.push(currentNode->left);
                if(currentNode->right )
                    Queue.push(currentNode->right);
                else if(currentNode->right == NULL&&currentNode->left != NULL)
                    Queue.push(currentNode->right);
            }
            if(!Queue.empty())
                cout<<",";
        }
        cout<<" ]"<<endl;
    }
    else
        cout<<" = [ Queue is Empty ]"<<endl;
}
int main()
{
    Solution solution;
    TreeNode *root=new TreeNode(1);
    root->left =new TreeNode(2);
    root->right=new TreeNode(2);
    root->left->left =new TreeNode(3);
    root->left->right=new TreeNode(4);
    root->right->left=new TreeNode(4);
    root->right->right=new TreeNode(3);
    cout<<"root1";
    printTree(root);
    if(solution.isSymmetric(root))
        cout<<"Symmetric"<<endl;
    else
        cout<<"No Symmetric"<<endl;
    root=new TreeNode(1);
    root->left =new TreeNode(2);
    root->right=new TreeNode(2);
    root->left->right =new TreeNode(3);
    root->right->right=new TreeNode(3);
    cout<<"root2";
    printTree(root);
    if(solution.isSymmetric(root))
        cout<<"Symmetric"<<endl;
    else
        cout<<"No Symmetric"<<endl;
    root = NULL;
    cout<<"root3";
    printTree(root);
    if(solution.isSymmetric(root))
        cout<<"Symmetric"<<endl;
    else
        cout<<"No Symmetric"<<endl;
    root=new TreeNode(2);
    cout<<"root4";
    printTree(root);
    if(solution.isSymmetric(root))
        cout<<"Symmetric"<<endl;
    else
        cout<<"No Symmetric"<<endl;
    root=new TreeNode(2);
    root->left=new TreeNode(3);
    cout<<"root5";
    printTree(root);
    if(solution.isSymmetric(root))
        cout<<"Symmetric"<<endl;
    else
        cout<<"No Symmetric"<<endl;
    return 0;
}
