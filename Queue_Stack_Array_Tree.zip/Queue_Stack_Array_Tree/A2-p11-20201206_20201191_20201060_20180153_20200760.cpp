/**
*Nada Mohamed Ahmed Gad El-kaream   20201191    s2
*Hager Mohamed Abd Elhalim Ghareeb  20201206    s2
*Donia Ahmed Abozeid Mohamed        20201060    s12
*Abd El-Rahman Taha Abd El-Bar      20180153    s10
*Ziad adel sayyed mohammed          20200760    s13
**/
#include <iostream>
using namespace std;
class BSTNode
{
public:
    int data;
    BSTNode*left;
    BSTNode*right;
    int balance;
    BSTNode()
    {
        left=right=NULL;
    }
    BSTNode(int value)
    {
        data=value;
        left=right=NULL;
    }
};
class BSTFCI
{
public:
    BSTNode*Root;
    BSTFCI()
    {
        Root=NULL;
    }
    void insert(int value)
    {
        if(Root == NULL)
            Root= new BSTNode(value);
        else
        {
            BSTNode*current=Root;
            while(current != NULL)
            {
                if(current->data > value)
                {
                    if(current->left != NULL)
                        current=current->left;
                    else
                    {
                        current->left=new BSTNode(value);
                        break;
                    }
                }
                else if(current->data < value)
                {
                    if(current->right != NULL)
                        current=current->right;
                    else
                    {
                        current->right=new BSTNode(value);
                        break;
                    }
                }
                else
                    break;
            }
        }
    }
    int height(BSTNode*node)
    {
        if(node == NULL)
            return 0;
        return max(height(node->left),height(node->right))+1;
    }
    bool IsBalanced(BSTNode*node)
    {
        if(node == NULL)
            return true;
        int left_height=height(node->left);
        int right_height=height(node->right);
        return(abs(left_height-right_height) <= 1 &&IsBalanced(node->left)&&IsBalanced(node->right));
    }
    void check_and_print(int data1,int data2,BSTNode*current,bool &f)
    {
        if(current == NULL)
            return;
        check_and_print(data1,data2,current->left,f);
        if(current->data >= data1&&current->data <= data2)
        {
            cout<<current->data<<" ";
            f=true;
        }
        check_and_print(data1,data2,current->right,f);
    }
    void printRange(int data1,int data2)
    {
        bool Found=false;
        if(Root == NULL)
            cout<<"Tree is Empty"<<endl;
        else
        {
            check_and_print(data1,data2,Root,Found);
            if(Found == false)
                cout<<" No Element Between [ "<<data1<<","<<data2<<" ]";
        }
    }
    void Inorder(BSTNode*root)
    {
        if(root == NULL)
            return;
        Inorder(root->left);
        cout<<root->data<<" ";
        Inorder(root->right);
    }
};
void String_Left_root(BSTNode*node,string &s)
{
    if(node == NULL)
        return;
    String_Left_root(node->left,s);
    s =s + to_string(node->data);
    String_Left_root(node->right,s);
}
bool isSubtree(BSTFCI*tree1,BSTFCI*tree2)
{
    if(tree2->Root == NULL)
        return true;
    else if(tree1->Root == NULL)
        return false;
    string s1,s2;
    BSTNode*currentNode=tree1->Root;
    while(currentNode->data != tree2->Root->data&&currentNode != NULL)
    {
        if(currentNode->data > tree2->Root->data)
            currentNode=currentNode->left;
        else
            currentNode=currentNode->right;
    }
    if(currentNode != NULL)
    {
        String_Left_root(currentNode,s1);
        String_Left_root(tree2->Root,s2);
        if(s1 == s2)
            return true;
        return false;
    }
    else
        return false;
}
int main()
{
    BSTFCI Bstfci1;
    Bstfci1.insert(5);
    Bstfci1.insert(3);
    Bstfci1.insert(7);
    Bstfci1.insert(2);
    Bstfci1.insert(4);
    Bstfci1.insert(9);
    Bstfci1.insert(8);
    Bstfci1.insert(10);
    Bstfci1.insert(1);
    cout<<"BSTFCI 1 : ";
    Bstfci1.Inorder(Bstfci1.Root);
    cout<<endl;
    //------------------------------
    cout<<"BSTFCI 1 : ";
    if(Bstfci1.IsBalanced(Bstfci1.Root))
        cout<<"Balance"<<endl;
    else
        cout<<"No Balance"<<endl;
    //---------------------------------
    cout<<endl<<"PrintRange(3,6)  from BSTFCI 1 : ";
    Bstfci1.printRange(3,6);
    cout<<endl<<"PrintRange(8,15) from BSTFCI 1 : ";;
    Bstfci1.printRange(8,15);
    cout<<endl<<"PrintRange(6,6)  from BSTFCI 1 : ";
    Bstfci1.printRange(6,6);
    cout<<endl<<"PrintRange(2,10) from BSTFCI 1 : ";
    Bstfci1.printRange(2,10);
    cout<<endl<<"PrintRange(5,8)  from BSTFCI 1 : ";
    Bstfci1.printRange(5,8);
    cout<<endl<<endl;
    //--------------------------------
    BSTFCI Bstfci2;
    Bstfci2.insert(9);
    Bstfci2.insert(8);
    Bstfci2.insert(10);
    cout<<"BSTFCI 2 : ";
    Bstfci1.Inorder(Bstfci2.Root);
    cout<<endl;
    //--------------------------------
    cout<<"BSTFCI 2 : ";
    if(Bstfci2.IsBalanced(Bstfci2.Root))
        cout<<"Balance"<<endl;
    else
        cout<<"No Balance"<<endl;
    //--------------------------------
    cout<<endl<<"BSTFCI 1 , BSTFCI 2 : ";
    if(isSubtree(&Bstfci1,&Bstfci2))
        cout<<"Subtree"<<endl;
    else
        cout<<"Not Subtree"<<endl;
    //--------------------------------
    BSTFCI Bstfci3;
    Bstfci3.insert(3);
    Bstfci3.insert(2);
    Bstfci3.insert(4);
    Bstfci3.insert(1);
    cout<<endl<<"BSTFCI 3 : ";
    Bstfci1.Inorder(Bstfci3.Root);
    cout<<endl;
    //--------------------------------
    cout<<"BSTFCI 3 : ";
    if(Bstfci3.IsBalanced(Bstfci3.Root))
        cout<<"Balance"<<endl;
    else
        cout<<"No Balance"<<endl;
    //--------------------------------
    cout<<endl<<"BSTFCI 1 , BSTFCI 3 : ";
    if(isSubtree(&Bstfci1,&Bstfci3))
        cout<<"Subtree"<<endl;
    else
        cout<<"Not Subtree"<<endl;
    //--------------------------------
    BSTFCI Bstfci4;
    Bstfci4.insert(3);
    Bstfci4.insert(2);
    Bstfci4.insert(4);
    cout<<endl<<"BSTFCI 4 : ";
    Bstfci1.Inorder(Bstfci4.Root);
    cout<<endl;
    //--------------------------------
    cout<<"BSTFCI 4 : ";
    if(Bstfci4.IsBalanced(Bstfci4.Root))
        cout<<"Balance"<<endl;
    else
        cout<<"No Balance"<<endl;
    //--------------------------------
    cout<<endl<<"BSTFCI 1 , BSTFCI 4 : ";
    if(isSubtree(&Bstfci1,&Bstfci4))
        cout<<"Subtree"<<endl;
    else
        cout<<"Not Subtree"<<endl;
    //--------------------------------
    BSTFCI Bstfci5;
    //--------------------------------
    cout<<endl<<"BSTFCI 5 , BSTFCI 4 : ";
    if(isSubtree(&Bstfci5,&Bstfci4))
        cout<<"Subtree"<<endl;
    else
        cout<<"Not Subtree"<<endl;
    //--------------------------------
    cout<<endl<<"BSTFCI 1 , BSTFCI 5 : ";
    if(isSubtree(&Bstfci1,&Bstfci5))
        cout<<"Subtree"<<endl;
    else
        cout<<"Not Subtree"<<endl;
    //--------------------------------
    return 0;
}
