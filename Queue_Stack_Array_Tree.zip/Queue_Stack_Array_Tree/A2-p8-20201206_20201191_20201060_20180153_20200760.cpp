/**
*Nada Mohamed Ahmed Gad El-kaream   20201191    s2
*Hager Mohamed Abd Elhalim Ghareeb  20201206    s2
*Donia Ahmed Abozeid Mohamed        20201060    s12
*Abd El-Rahman Taha Abd El-Bar      20180153    s10
*Ziad adel sayyed mohammed          20200760    s13
**/
#include <iostream>
#include <string>
using namespace std;
class node{
public:
    char data;
    node* left,*right;
    node(char d){
        data=d;
        left=right=NULL;
    }
};
class construct_Tree {
public:
    node* root;
    construct_Tree(){
        root=NULL;
    }
    int search(char first, const string& s) {
        for (int i = 0; i < s.size(); i++)
            if (s[i] == first)
                return i;
        return -1;
    }
    node* tree(node*rr,const string& p,const string& in){
        if(p.empty()||in.empty()){
            return rr;
        }
        rr=new node(p[0]);
        int c = search(p[0], in);
        rr->left=tree(rr->left,p.substr(1,c),in.substr(0,c));
        rr->right=tree(rr->right,p.substr(c+1,p.size()),in.substr(c+1,in.size()));
        return rr;

    }
    void printPostOrder( const string &p, const string& n) {
        root= tree(root,p,n);
        post(root);
    }
    void post(node*rr){
        if(rr==NULL){
            return;
        }
        post(rr->left);
        post(rr->right);
        cout<<rr->data;
    }
};
int main()
{
    string in = "FBGAC";
    string pre = "ABFGC";
    cout<<"case 1"<<endl;
    cout<<"given inOrder traversal\n"<<in<<endl;
    cout<<"given preOrder traversal\n"<<pre<<endl;
    cout<<"PostOrder traversal " << endl;
    construct_Tree t1;
    t1.printPostOrder(pre,in);
    cout <<"\n....................................................\n";

    string in2 = "ABCDEF";
    string pre2 = "DBACEF";
    cout<<"case 2"<<endl;
    cout<<"given inOrder traversal\n"<<in2<<endl;
    cout<<"given preOrder traversal\n"<<pre2<<endl;
    cout<<"PostOrder traversal " << endl;
    construct_Tree t2;
    t2.printPostOrder(pre2, in2);
    cout <<"\n....................................................\n";

    string in3 = "RSTUV";
    string pre3 = "USRTV";
    cout<<"case 3"<<endl;
    cout<<"given inOrder traversal\n"<<in3<<endl;
    cout<<"given preOrder traversal\n"<<pre3<<endl;
    cout<<"PostOrder traversal " << endl;
    construct_Tree t3;
    t3.printPostOrder(pre3, in3);
    cout <<"\n....................................................\n";

    string in4 = "THBUAFCR";
    string pre4 = "ABHTUCFR";
    cout<<"case 4"<<endl;
    cout<<"given inOrder traversal\n"<<in4<<endl;
    cout<<"given preOrder traversal\n"<<pre4<<endl;
    cout<<"PostOrder traversal " << endl;
    construct_Tree t4;
    t4.printPostOrder(pre4, in4);
    cout <<"\n....................................................\n";

    string in5 = "FDCEG";
    string pre5= "CDFEG";
    cout<<"case 5"<<endl;
    cout<<"given inOrder traversal\n"<<in5<<endl;
    cout<<"given preOrder traversal\n"<<pre5<<endl;
    cout<<"PostOrder traversal " << endl;
    construct_Tree t5;
    t5.printPostOrder(pre5, in5);
    cout <<"\n....................................................\n";

    return 0;
}
