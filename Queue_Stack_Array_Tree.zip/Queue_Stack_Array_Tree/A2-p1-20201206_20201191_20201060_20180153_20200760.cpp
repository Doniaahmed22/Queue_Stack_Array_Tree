/**
*Nada Mohamed Ahmed Gad El-kaream   20201191    s2
*Hager Mohamed Abd Elhalim Ghareeb  20201206    s2
*Donia Ahmed Abozeid Mohamed        20201060    s12
*Abd El-Rahman Taha Abd El-Bar      20180153    s10
*Ziad adel sayyed mohammed          20200760    s13
**/
#include <iostream>
#include <cstdlib>
using namespace std;
#define SIZE 10
template <class X>
class stack
{
    X *arr;
    int top;
    int capacity;
public:
    stack(int size = SIZE);
    void push(X);
    X pop();
    X theTop();
    int size();
    bool isEmpty();
    bool isFull();

    ~stack() {
        delete[] arr;
    }
};

template <class X>
stack<X>::stack(int size)
{
    arr = new X[size];
    capacity = size;
    top = -1;
}
template <class X>
void stack<X>::push(X x)
{
    if (isFull())
    {
        cout << "Overflow\nProgram Terminated\n";
        exit(EXIT_FAILURE);
    }

    arr[++top] = x;
}

template <class X>
X stack<X>::pop()
{

    if (isEmpty())
    {
        cout << "Underflow\nProgram Terminated\n";
        exit(EXIT_FAILURE);
    }

    return arr[top--];
}


template <class X>
X stack<X>::theTop()
{
    if (!isEmpty()) {
        return arr[top];
    }
    else {
        exit(EXIT_FAILURE);
    }
}


template <class X>
int stack<X>::size() {
    return top + 1;
}


template <class X>
bool stack<X>::isEmpty() {
    return top == -1;
}


template <class X>
bool stack<X>::isFull() {
    return top == capacity - 1;
}

string simplifiedCanonical(string A)
{
    stack<string> stackk;
    string directory;
    string remaining;
    remaining.append("/");
    int len_A = A.length();
    for (int i = 0; i < len_A; i++) {
        directory.clear();
        while (A[i] == '/')
            i++;
        while (i < len_A && A[i] != '/') {
            directory.push_back(A[i]);
            i++;
        }
        if (directory.compare("..") == 0) {
            if (!stackk.isEmpty())
                stackk.pop();
        }
        else if (directory.compare(".") == 0) { continue; }
        else if (directory.length() != 0)
            stackk.push(directory);
    }
    stack<string> rStackk;
    while (!stackk.isEmpty()) {
        rStackk.push(stackk.theTop());
        stackk.pop();
    }
    while (!rStackk.isEmpty()) {
        string temp = rStackk.theTop();

        if (rStackk.size() != 1)
            remaining.append(temp + "/");
        else
            remaining.append(temp);
        rStackk.pop();
    }
    return remaining;
}
int main()
{
    string test("/a/./b/../");
    string result = simplifiedCanonical(test);
    cout << result<<endl;
    string test1("/home/");
    result = simplifiedCanonical(test1);
    cout << result<<endl;
    string test2("/../");
    result = simplifiedCanonical(test2);
    cout << result << endl;
    string test3("/home//foo/");
    result = simplifiedCanonical(test3);
    cout << result<<endl;
    return 0;
}
