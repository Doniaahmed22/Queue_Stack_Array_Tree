/**
*Nada Mohamed Ahmed Gad El-kaream   20201191    s2
*Hager Mohamed Abd Elhalim Ghareeb  20201206    s2
*Donia Ahmed Abozeid Mohamed        20201060    s12
*Abd El-Rahman Taha Abd El-Bar      20180153    s10
*Ziad adel sayyed mohammed          20200760    s13
**/
#include <iostream>
using namespace std;
class node
{
public:
    int data;
    node* left;
    node* right;
};
bool isStructSame(node* a, node* b)
{
    if (a == NULL && b == NULL)
        return true;
    if (a != NULL && b != NULL && isStructSame(a->left, b->left) && isStructSame(a->right, b->right))
        return true;
    return false;
}
void mirror(node* Node)
{
    if (Node == NULL)
        return;
    else
    {
        node* temp;
        mirror(Node->left);
        mirror(Node->right);
        temp = Node->left;
        Node->left = Node->right;
        Node->right = temp;
    }
}
bool isFoldable(node* root)
{
    bool res;
    if (root == NULL)
        return true;
    mirror(root->left);
    res = isStructSame(root->left, root->right);
    mirror(root->left);
    return res;
}
node* newNode(int data)
{
    node* Node = new node();
    Node->data = data;
    Node->left = NULL;
    Node->right = NULL;
    return (Node);
}
int main(void)
{
    node* root = newNode(1);
    root->left = newNode(2);
    root->right = newNode(3);
    root->right->left = newNode(4);
    root->left->right = newNode(5);
    if (isFoldable(root))
        cout << "Tree is Foldable"<<endl;
    else
        cout << "Tree is Not Foldable"<<endl;
    node* root1 = newNode(1);
    root1->left = newNode(4);
    root1->right = newNode(2);
    root1->right->left = newNode(3);
    root1->left->right = newNode(5);
    if (isFoldable(root1))
        cout << "Tree is Foldable"<<endl;
    else
        cout << "Tree is Not Foldable"<<endl;
    node* root2 = newNode(1);
    root2->left = newNode(2);
    root2->right = newNode(3);
    root2->left->left=newNode(4);
    root2->right->right=newNode(5);
    root2->left->right = newNode(6);
    if (isFoldable(root2))
        cout << "Tree is Foldable"<<endl;
    else
        cout << "Tree is Not Foldable"<<endl;
    node* root3=NULL;
    if (isFoldable(root3))
        cout << "Tree is Foldable"<<endl;
    else
        cout << "Tree is Not Foldable"<<endl;
    node* root4=newNode(2);
    root4->left=newNode(3);
    if (isFoldable(root4))
        cout << "Tree is Foldable"<<endl;
    else
        cout << "Tree is Not Foldable"<<endl;
    return 0;
    return 0;
}
