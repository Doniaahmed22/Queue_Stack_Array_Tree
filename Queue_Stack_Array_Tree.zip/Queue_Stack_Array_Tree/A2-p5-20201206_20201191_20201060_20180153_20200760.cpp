/**
*Nada Mohamed Ahmed Gad El-kaream   20201191    s2
*Hager Mohamed Abd Elhalim Ghareeb  20201206    s2
*Donia Ahmed Abozeid Mohamed        20201060    s12
*Abd El-Rahman Taha Abd El-Bar      20180153    s10
*Ziad adel sayyed mohammed          20200760    s13
**/
#include <iostream>
using namespace std;
struct TreeNode
{
    int val;
    TreeNode *left;
    TreeNode *right;
    TreeNode() : val(0), left(nullptr), right(nullptr) {}
    TreeNode(int x) : val(x), left(nullptr), right(nullptr) {}
    TreeNode(int x, TreeNode *left, TreeNode *right) : val(x), left(left),
        right(right) {}
};
class Solution
{
public:
    bool isSameTree(TreeNode* p, TreeNode* q)
    {
        if (p == nullptr && q == nullptr)
            return 1;

        if (p != nullptr && q != nullptr)
        {
            return
                (
                    p->val == q->val &&
                    isSameTree(p->left, q->left) &&
                    isSameTree(p->right, q->right)
                );
        }
        return 0;
    }
};
int main()
{
    //3 cases
    Solution s1;
    cout<<"********************************************************"<<endl;
    cout<<"  case 1"<<endl;
    TreeNode *node1 = new TreeNode(1);
    TreeNode *node2 = new TreeNode(1);
    node1->left = new TreeNode(2);
    node1->right = new TreeNode(3);
    node2->left = new TreeNode(2);
    node2->right = new TreeNode(3);
    if(s1.isSameTree(node1,node2))
    {
        cout<<" two trees are same"<<endl;
        cout<<"********************************************************"<<endl;
        return true;
    }
    else
    {
        cout << "two trees are not the same"<<endl;
        cout<<"********************************************************"<<endl;
        return false;
    }
    cout<<"  case 2"<<endl;
    TreeNode *node3 = new TreeNode(1);
    TreeNode *node4 = new TreeNode(1);
    node3->left = new TreeNode(2);
    node4->right = new TreeNode(2);
    if(s1.isSameTree(node3,node4))
    {
        cout<<" two trees are  the same"<<endl;
        cout<<"********************************************************"<<endl;
        return true;
    }
    else
    {
        cout << "two trees are not the same."<<endl;
        cout<<"********************************************************"<<endl;
        return false;
    }
    cout<<"  case 3"<<endl;
    TreeNode *node5 = new TreeNode(1);
    TreeNode *node6 = new TreeNode(1);
    node5->left = new TreeNode(2);
    node5->right = new TreeNode(1);
    node6->left = new TreeNode(1);
    node6->right = new TreeNode(2);
    if(s1.isSameTree(node5,node6))
    {
        cout<<" two trees are  the same"<<endl;
        cout<<"********************************************************"<<endl;
        return true;
    }
    else
    {
        cout << "two trees are not the same."<<endl;
        cout<<"********************************************************"<<endl;
        return false;
    }
    return 0;
}
