/**
*Nada Mohamed Ahmed Gad El-kaream   20201191    s2
*Hager Mohamed Abd Elhalim Ghareeb  20201206    s2
*Donia Ahmed Abozeid Mohamed        20201060    s12
*Abd El-Rahman Taha Abd El-Bar      20180153    s10
*Ziad adel sayyed mohammed          20200760    s13
**/
#include<iostream>
using namespace std;

struct Node
{
    int data;
    struct Node* left;
    struct Node* right;

};
//construct the tree
Node* newNode(int data)
{
    Node* node = new Node;
    node->data = data;
    node->left = NULL;
    node->right = NULL;

    return(node);
}
//flip the tree as a mirror
void flip(Node* node=NULL)
{
    if (node == NULL)
       return;

    else
    {
        Node* temp;

        flip(node->left);
        flip(node->right);

        temp = node->left;
        node->left = node->right;
        node->right = temp;
    }
}
//print the flip tree by inorder method as an example
void inOrder(struct Node* node)
{
    if (node == NULL)
        return;

    inOrder(node->left);
    cout << node->data << " ";
    inOrder(node->right);
}

int main()
{
///first case
cout<<"first test case is : \n";
    struct Node *root1= newNode(1);
    root1->left = newNode(2);
    root1->right = newNode(3);
    root1->left->left = newNode(4);
    root1->left->right = newNode(5);

    cout << "tree before flipping.\n";
    inOrder(root1);

    flip(root1);

    cout << "\ntree after flipping.\n";
    inOrder(root1);
cout<<"\n.................................................................\n"<<endl;

///second case
cout<<"second test case is : \n";
    struct Node *root2 = newNode(1);
    root2->left = newNode(7);
    root2->right = newNode(3);
    root2->left->left = newNode(4);
    root2->left->right = newNode(5);
    root2->right->left = newNode(6);
    root2->right->right = newNode(6);

    cout << "tree before flipping.\n";
    inOrder(root2);

    flip(root2);

    cout << "\ntree after flipping.\n";
    inOrder(root2);
cout<<"\n.................................................................\n"<<endl;

///third case
cout<<"third test case is : \n";
    struct Node *root3 = newNode(1);
    root3->left = newNode(7);
    root3->right = newNode(3);
    root3->left->left = newNode(4);
    root3->left->right = newNode(5);
    root3->right->left = newNode(6);
    root3->right->right = newNode(9);
    root3->right->left->left = newNode(8);
    root3->right->right->right = newNode(11);

    cout << "tree before flipping.\n";
    inOrder(root3);

    flip(root3);

    cout << "\ntree after flipping.\n";
    inOrder(root3);
cout<<"\n.................................................................\n"<<endl;

///forth case
cout<<"forth test case is : \n";
    struct Node *root4 = newNode(1);
    root4->left = newNode(7);
    root4->right = newNode(3);
    root4->left->left = newNode(4);

    cout << "tree before flipping.\n";
    inOrder(root4);

    flip(root4);

    cout << "\ntree after flipping.\n";
    inOrder(root4);
cout<<"\n.................................................................\n"<<endl;

///fifth case
cout<<"fifth case is : \n";
    struct Node *root5 = newNode(1);
    root5->left = newNode(7);
    root5->right = newNode(3);
    root5->left->left = newNode(4);
    root5->left->left->left = newNode(5);
    root5->right->left = newNode(6);
    root5->right->right = newNode(9);

    cout << "tree before flipping.\n";
    inOrder(root5);

    flip(root5);

    cout << "\ntree after flipping.\n";
    inOrder(root5);
cout<<"\n................................................................."<<endl;

 return 0;
}


