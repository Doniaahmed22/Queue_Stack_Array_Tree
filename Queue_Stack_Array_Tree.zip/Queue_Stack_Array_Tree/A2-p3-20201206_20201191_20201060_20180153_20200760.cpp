/**
*Nada Mohamed Ahmed Gad El-kaream   20201191    s2
*Hager Mohamed Abd Elhalim Ghareeb  20201206    s2
*Donia Ahmed Abozeid Mohamed        20201060    s12
*Abd El-Rahman Taha Abd El-Bar      20180153    s10
*Ziad adel sayyed mohammed          20200760    s13
**/
#include <iostream>
#include <queue>
using namespace std;
class Stack
{
private:
    queue<int>Queue_Stack;
public:
    void push(int value)
    {
        queue<int> New_Queue_Stack;
        New_Queue_Stack.push(value);
        while(!Queue_Stack.empty())
        {
            New_Queue_Stack.push(Queue_Stack.front());
            Queue_Stack.pop();
        }
        Queue_Stack=New_Queue_Stack;
    }
    void pop()
    {
        if(!Queue_Stack.empty())
            Queue_Stack.pop();
        else
            cout<<"Pop : Stack is Empty"<<endl;
    }
    int top()
    {
        if(!Queue_Stack.empty())
            return Queue_Stack.front();
        throw("Top : No Element in Stack ");
    }
};
int main()
{
    Stack s;
    try
    {
        s.push(-1);
        s.push(1);
        s.push(2);
        s.push(3);
        cout<<s.top()<<endl;// -1 1 2 3
        s.pop(); // 3
        s.push(4); // -1 1 2 4
        s.pop();// 4
        cout<<s.top()<<endl;// 2
        s.pop(); // 2
        s.pop(); // 1
        s.pop(); // -1
        s.pop(); // No
        s.top(); // No
    }
    catch(const char*ex)
    {
        cout<<ex<<endl;
        s.push(8);
        cout<<s.top()<<endl;
    }
    return 0;
}
