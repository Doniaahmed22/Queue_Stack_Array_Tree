/**
*Nada Mohamed Ahmed Gad El-kaream   20201191    s2
*Hager Mohamed Abd Elhalim Ghareeb  20201206    s2
*Donia Ahmed Abozeid Mohamed        20201060    s12
*Abd El-Rahman Taha Abd El-Bar      20180153    s10
*Ziad adel sayyed mohammed          20200760    s13
**/
#include <iostream>
using namespace std;
struct Node
{
    int data;
    Node* left, * right;
};

struct Node *createNode(int data)
{
    Node * new_Node = new Node;
    new_Node->left = NULL;
    new_Node->right = NULL;
    new_Node->data = data;
    return new_Node;
}

struct Node * insert(Node *root, int key)
{
    if (root == NULL)
        return createNode(key);

    if (root->data > key)
        root->left = insert(root->left, key);

    else if (root->data < key)
        root->right = insert(root->right, key);

    return root;
}

int ksmallestElementSumRec(Node *root, int k, int &count)
{
    if (root == NULL)
        return 0;
    if (count > k)
        return 0;

    int res = ksmallestElementSumRec(root->left, k, count);
    if (count >= k)
        return res;

    res += root->data;

    count++;
    if (count >= k)
        return res;

    return res + ksmallestElementSumRec(root->right, k, count);
}

int ksmallestElementSum(struct Node *root, int k)
{
    int count = 0;
    ksmallestElementSumRec(root, k, count);
}

int main()
{
    int k;
    Node *root = NULL;
    root = insert(root, 54);
    root = insert(root, 51);
    root = insert(root, 75);
    root = insert(root, 49);
    root = insert(root, 52);
    root = insert(root, 74);
    root = insert(root, 85);
    k = 1;
    cout << ksmallestElementSum(root, k) <<endl;
    k = 2;
    cout << ksmallestElementSum(root, k) <<endl;
    k = 3;
    cout << ksmallestElementSum(root, k) <<endl;
    k = 4;
    cout << ksmallestElementSum(root, k) <<endl;
    k = 5;
    cout << ksmallestElementSum(root, k) <<endl;

    return 0;
}

