/**
*Nada Mohamed Ahmed Gad El-kaream   20201191    s2
*Hager Mohamed Abd Elhalim Ghareeb  20201206    s2
*Donia Ahmed Abozeid Mohamed        20201060    s12
*Abd El-Rahman Taha Abd El-Bar      20180153    s10
*Ziad adel sayyed mohammed          20200760    s13
**/
#include <iostream>
#include <cstdlib>
#include <vector>
using namespace std;

#define SIZE 10
template <class T>
class queue
{
    T *arr;
    int capacity;
    int front;
    int rear;
    int count;

public:
    queue(int size = SIZE);

    void dequeue();
    void enqueue(T x);
    T peek();
    int size();
    bool isEmpty();
    bool isFull();
};
template <class T>
queue<T>::queue(int size)
{
    arr = new T[size];
    capacity = size;
    front = 0;
    rear = -1;
    count = 0;
}

template <class T>
void queue<T>::dequeue()
{

    if (isEmpty())
    {
        cout << "Underflow\nProgram Terminated\n";
        exit(EXIT_FAILURE);
    }
    front = (front + 1) % capacity;
    count--;
}
template <class T>
void queue<T>::enqueue(T item)
{
    if (isFull())
    {
        cout << "Overflow\nProgram Terminated\n";
        exit(EXIT_FAILURE);
    }

    rear = (rear + 1) % capacity;
    arr[rear] = item;
    count++;
}
template <class T>
T queue<T>::peek()
{
    if (isEmpty())
    {
        cout << "UnderFlow\nProgram Terminated\n";
        exit(EXIT_FAILURE);
    }
    return arr[front];
}
template <class T>
int queue<T>::size() {
    return count;
}

template <class T>
bool queue<T>::isEmpty() {
    return (size() == 0);
}

template <class T>
bool queue<T>::isFull() {
    return (size() == capacity);
}

int time(vector<int>& tickets, int k) {
    queue<pair<int,int>>q;
    int time = 0;
    for(int i = 0; i < tickets.size(); i++)
    {
        q.enqueue({tickets[i],i});
    }
    while(!q.isEmpty())
    {
        pair<int,int> temp = q.peek();
        q.dequeue();
        --temp.first;
        ++time;
        if(temp.first == 0 && temp.second == k)
        {
            break;
        }
        else if(temp.first != 0)
        {
            q.enqueue({temp.first, temp.second});
        }
    }
    return time;
}
int main(){
    vector<int> vector1 = {2, 3, 2 };
    cout << time(vector1, 2);
}
